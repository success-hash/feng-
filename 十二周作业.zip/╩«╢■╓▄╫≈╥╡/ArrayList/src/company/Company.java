package company;
public interface Company {
   public double fei();
}
