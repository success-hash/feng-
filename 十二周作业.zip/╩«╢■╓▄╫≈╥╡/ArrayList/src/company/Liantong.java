package company;
public class Liantong implements Company{
     public double fei() {
    	 double s=0.25;
    	 System.out.println("��ͨÿ����"+s+"Ԫ��");
    	 return s;
     }
}
