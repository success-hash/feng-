package company;
public class Yidong implements Company{
     public double fei() {
    	 double s=0.3;
    	 System.out.println("�ƶ�ÿ����"+s+"Ԫ��");
    	 return s;
     }
}
