package name;
import company.*;
public interface Dianxin {
      public Company productCompany();
}
