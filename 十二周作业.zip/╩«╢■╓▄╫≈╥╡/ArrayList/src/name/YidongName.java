package name;
import company.*;
public class YidongName implements Dianxin{
            public Company productCompany() {
            	return new Yidong();
            }
}
