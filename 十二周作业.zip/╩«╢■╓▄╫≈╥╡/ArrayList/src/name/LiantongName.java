package name;
import company.*;
public class LiantongName implements Dianxin{
            public Company productCompany() {
            	return new Liantong();
            }
}
