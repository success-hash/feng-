
public class Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		Movie m1=new Movie("Java",new ChildrensPrice());
		Movie m2=new Movie("C++",new NewReleasePrice());
		Movie m3=new Movie("Python",new NewReleasePrice());
		
		
	    System.out.println("+++");	
	}
}
