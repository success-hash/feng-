package car;

public interface car {
     public  double fei ();
     
}
